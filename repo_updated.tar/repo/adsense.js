(function() {
  var ads = document.createElement('script');
  ads.async = true;
  ads.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
  ads.setAttribute('data-ad-client', "ca-pub-5000547699906372");
  document.head.appendChild(ads);
})();
